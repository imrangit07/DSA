
    // auto j = s.find(99); // WITHOUT FIND SEGMENTATION FAULT

    // if (j != s.end())
    // {
    //     cout << "found" << endl; // IF NO DATA FIND SEGMENTATION FAULT
    // }
    // else
    // {
    //     cout << "Not Found" << endl; // if 99 key not found
    // }